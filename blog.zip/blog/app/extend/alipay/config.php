<?php
$config = array (	
		//应用ID,您的APPID。
		'app_id' => "2016092300575300",

		//商户私钥，您的原始格式RSA私钥
		'merchant_private_key' => "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDEQtM/38euKrwvjFTftrOeU7iBsADKQyWRMot6aA0VExbPcw7fDu5OA2go3Dfis5uDk2HpXbjYYm7rzPs6Nk9tZ9DRZvuKnoaXBl0HCARWwo54PJRXwh2zCjuSFDjb1EG800njB7EFpfgpJ79CI/Xz4OVg+06O76AjqpIGZbOoqcK0V98muLWeQebNoopdPLXQrMrBsv1cox9CCyCBUuqX6m6dbQzrd7d+1thDjeyheUSyji93XEaqGNUNvg8jsrWAkOTmpWd5SLTcjA0GFA7NB0CfQfgaIjVCZSN5XcQQgSUqARZ2j5mcMjuSi2X8ETY9KS7Of04O+nBCNXeNVYPzAgMBAAECggEAIFPNjijjMDoT01UvKcZjYcHyk1IVXzueNYN43AnFleIWEMen/G/uKuV+w7Q6dFoXVJ3zM8hfSS01jhuuihEmFiRSjhuDdXrVOo0ux5i3dj8HzqBT4vyzfalC1LYGA5e72EmJUx8SNpb3AHhulYts2OYDgm0CrKKl4xoWgX1BEZfSoxZdv0ldaDRftbITaKC7dQt6mjqVYiRFdauUDxdlQ9Ga8RA3DFJNVM/J6LweKbVWTXvboGTYRpowk6JLpSRSFZasI5s2ZUGCcBZcjJq9+/nUM5eJc/5atvkOCAIYywc8eomn+vHY1g8ezpkA+Bkex2oDNfzWpL0W7LQDBQr9KQKBgQD4PHHr5q2OQMb6gGJzwZoNYQnypzCt3SL5c+wmy3+f4nSYxspKn5yTGn8fFRVkdNP/eoKHRxXIk7iS6qusfFX9LDwccB3pffPCFuXjT2DA3ZFhgkaIg2y7H/MAUoksD8GQmLwTP5HDv8/Vk67zcnZqJe6qu1L0FZ/MjCB1fSAT1QKBgQDKZjsQ7OvDRpO0+UggB5rgpSliy0AJhcT6Jdc4ohV+qaE3E5Qr+tyxHLizBuoCVTWlJikt3L22zWUXhqEL2P9x4BBZVFMJAoUGdv4CwFJYSBw/4gKMmleAsh1nlzwpFh1WD5gw/l1vOdhPnZaF6PWUd5YWUsZdBQEZ0LcUrZREpwKBgGd2MfkjfQTEROqVZfNfJskav92uB2D/wRr9UNjeikPmS7h9akTt/4FkUsVusSrccpuRwSOG4jJmN1CslH7gl6pcrHUh2aW+xEEJ8CjspaPc9UIR3Tn6pO/dIhfpTpjZvFB7CDBxl1xh7srSseFvvKEDTFVGnA11kdPcN48gZqU9AoGAMQ1DpV915/aT15lOlIyjSWxdslbF50jnKyS+mzgU84SS0LFLCLmcgMQQMzsqvXP/M04jTr0fsUzoAiKbpy5pAiUmcS/Ri+5zZNSzzODlVAXt6sGQkpjZOhRwseliKCb25yOSY9VRuaIQPYNYto117wxocHKRJnwO/z2pETbcJyMCgYAw4hh7W/bCcJgL9PZPj+Rd09cI0/gqFY+a8qpUlq2wKkckjsM/tuZEhCzpIto8EDit0LYHeOEAXpKtR1TSljjL7FLKUl8VqRHMpidALO69Xze1TjVFQzlKjI1DlZPbUURuYriBYLQQfHx3Bpsxc2WZ4T+VQyZjXhfVhf/WzT8FZQ==",
		
		//异步通知地址
		'notify_url' => "http://120.79.215.142/tell",
			// 'notify_url' => "http://www.1809.com/tell",
		
		//同步跳转
		'return_url' => "http://120.79.215.142/result",
			// 'return_url' => "http://www.1809.com/result",

		//编码格式
		'charset' => "UTF-8",

		//签名方式
		'sign_type'=>"RSA2",

		//支付宝网关
		'gatewayUrl' => "https://openapi.alipaydev.com/gateway.do",

		//支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
		'alipay_public_key' => "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAohWhc+8GFWcLrj1XZelDojhPHZnPHOAZT84wc6SlZNdF88FBac2mz2YDLXKtMFvzjSJOytNipgBm07kZbaeq7AaygRswpHUhiv/74roMdkJBCUzO7CujWEcSH5GdU80Wsq7nw6weyqUg3EJE2x6PKNbC9u0sOawM2jDz7FpaOOoYDdmo1AK3gJ3Hiqbvn1j+Q/iOa4n/fCGJ5DpBTRsnnvnTH4vIdBr7fSaIyWUB3JTn+xjyXxWmTuqPoCTuVVVQ+5XC2ZsCjIHYRy+LIMeyB/LYY5lqsBc9tp1w6b0OePQpZ6LkV+qFO/ly+I+jZhep1LHWH7pXVHDu1GuqYhwrxwIDAQAB",
		
	
);
return $config;
